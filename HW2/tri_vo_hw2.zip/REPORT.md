# CS 557 Fall 2026 — Homework 2 Report: Policy Gradient and Actor-Critic Methods

**Author:** Tri Vo (`vo43@purdue.edu`)
**Course:** CS 557 — Reinforcement Learning I (Purdue University, Fall 2026)
**Environments:** `MountainCarContinuous-v0` (Threshold: `+90.0`), `BipedalWalker-v3` (Threshold: `+300.0`)
**Algorithms:** REINFORCE (Part 1A), PPO (Part 1B & Part 2), Soft Actor-Critic / SAC (Part 1C Bonus)

---

## Executive Summary & Threshold Verification

All three continuous-control algorithms (`REINFORCEAgent`, `PPOAgent`, `SACAgent`) were implemented, mathematically verified via unit tests and Andy Jones probe environments (`test_agents.py`), and evaluated across both Gymnasium environments without modifying any environment reward functions. Every solvable task meets and exceeds its official Gymnasium success threshold on both TensorBoard checkpoint evaluation and held-out 20-episode (and 100-episode) deterministic evaluation (`verify_all_results.py`):

| Part | Algorithm | Environment | Steps | Train Last-10 (Mean ± Std) | TB Final Eval | Held-Out Eval (20 eps) | Threshold | Status |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **1A** | REINFORCE | `MountainCarContinuous-v0` | 200,764 | `-31.49 ± 1.28` | `-1.80` | `-1.80 ± 0.01` | `+90.0` | Expected Failure (per spec) |
| **1B** | PPO + gSDE | `MountainCarContinuous-v0` | 200,047 | `+95.07 ± 0.28` | `+95.18` | **`+95.17 ± 0.17`** | `+90.0` | **PASS** |
| **1C** | SAC + OU Warmup | `MountainCarContinuous-v0` | 200,061 | `+94.94 ± 0.27` | `+94.73` | **`+94.98 ± 0.33`** | `+90.0` | **PASS** |
| **1A** | REINFORCE | `BipedalWalker-v3` | 201,432 | `-85.86 ± 30.36` | `-113.79` | `-118.11 ± 18.92` | `+300.0` | Expected Failure (per spec) |
| **1B** | PPO Baseline | `BipedalWalker-v3` | 200,424 | `+39.97 ± 17.30` | `-109.55` | `-109.56 ± 0.13` | `+300.0` | Under-tuned Baseline (see Part 2) |
| **1C** | SAC Tuned | `BipedalWalker-v3` | 500,509 | `+294.06 ± 87.43` | `+328.86` | **`+328.79 ± 0.70`** (20/20 ≥ 300; 100-ep: `326.64 ± 21.98`) | `+300.0` | **PASS** |
| **2B** | PPO Tuned | `BipedalWalker-v3` | 2,500,034 | `+306.50 ± 1.79` | `+306.66` | **`+307.75 ± 1.48`** (20/20 ≥ 300; 100-ep: `301.54 ± 44.63`) | `+300.0` | **PASS** |

---

## Key Bug Fixes & Engineering Improvements

During implementation and experimental auditing, several subtle RL bugs and exploration bottlenecks were identified and resolved cleanly without modifying environment rewards:

1. **SAC Truncation vs. True Termination (`sac.py`)**: Previously, `done = terminated or truncated` was stored directly as the terminal flag in the replay buffer. On `BipedalWalker-v3` (1,600-step limit) and `MountainCarContinuous-v0` (999-step limit), time-limit truncation caused the Bellman target to zero out future returns `(1 - done) * Q_next = 0`, severely biasing Q-values near horizon boundaries. Separating `float(terminated)` for bootstrapping while keeping `done` for episode resets fixed target estimation.
2. **SAC Temperature Gradient Isolation (`sac.py`)**: `self.alpha` was stored with gradient history attached (`self.log_alpha.exp()`), leaking gradients between `policy_loss` and `alpha_loss`. Detaching `self.alpha = self.log_alpha.exp().detach()` and recomputing `self.log_alpha.exp()` inside `alpha_loss` isolated the dual optimization cleanly.
3. **Replay Buffer Efficiency (`sac.py`)**: Replaced the `collections.deque` replay buffer (`O(N)` random sampling) with a pre-allocated NumPy ring buffer, cutting CPU/GPU overhead dramatically.
4. **Temporally Correlated Exploration on `MountainCarContinuous-v0` (`ppo.py`, `sac.py`)**: Uncorrelated i.i.d. Gaussian or uniform actions push back and forth around the valley floor (`x ≈ -0.5`), incurring `-0.1 * a^2` fuel cost without ever reaching `x ≥ 0.45` (+100 goal). Enabling optional Generalized State-Dependent Exploration (`--use_sde`) + running observation normalization (`--norm_obs`, stored as buffers for `eval()` parity) in PPO and Ornstein-Uhlenbeck warmup noise (`--ou_warmup`) in SAC allowed both agents to discover the goal rapidly while preserving unmodified Gymnasium rewards.
5. **Collision-Free Logging & Checkpointing (`logger.py`, `reinforce.py`, `ppo.py`, `sac.py`)**: Added unique timestamp + collision-safe run names (`logger.run_name`) and checkpoint prefixes so parallel Slurm sweeps never overwrite each other.
6. **Exact Run Selection in Analysis (`plot_and_analyze.py`)**: Replaced substring prefix matching with exact hyperparameter token parsing (`find_exact_run` + `forbidden_keys`) so ablation curves never mix mismatched configs.

---

## Part 1A: REINFORCE (Monte-Carlo Policy Gradient)

### Implementation Summary (`reinforce.py`)
- **`select_action`**: Passes state through a 2-layer 256-unit ReLU MLP predicting action mean `mu` alongside a learnable `log_std` parameter (clamped to `[-5.0, 0.0]` after updates), samples `raw_action ~ Normal(mu, std)`, maps to `[action_low, action_high]`, and returns both scaled action and scalar log-probability.
- **`calculate_discounted_returns`**: Computes exact Monte-Carlo discounted returns `G_t = r_t + gamma * G_{t+1}` in reverse order, normalized per episode `(G - mean(G)) / (std(G) + 1e-8)`.
- **`train_reinforce`**: Accumulates `(log_prob, reward)` over full episodes and minimizes `-(log_probs * returns).sum()`, logging episode reward, policy loss, policy std, episode length, gradient norm, and periodic deterministic evaluations (`utils.evaluate_policy`).

### Performance & Analysis
- **`MountainCarContinuous-v0`**: Over 200,764 steps (`lr=5e-5, gamma=0.99`), REINFORCE reached `+69.37` in only a single lucky episode (~182k steps) before collapsing back to a last-10 training mean of `-31.49 ± 1.28` and deterministic eval of `-1.80 ± 0.01`. With i.i.d. per-step Gaussian noise, the car almost never builds momentum up the hill; the only consistent gradient comes from the `-0.1 * a^2` control penalty, driving the policy mean toward zero.
- **`BipedalWalker-v3`**: Over 201,432 steps (`lr=5e-5, gamma=0.99`), REINFORCE averaged `-85.86 ± 30.36` over the last 10 training episodes and `-118.11 ± 18.92` on 20 deterministic evaluation episodes. Because a single full-episode Monte-Carlo return assigns the same credit to every step in a 100–1,600 step trajectory without a learned critic baseline, high gradient variance prevents coherent multi-joint locomotion.
- **Plots**: `plots/part1_mountaincar_reward.png`, `plots/part1_bipedal_reward.png`, `plots/part1_reinforce_losses.png`.

---

## Part 1B: Proximal Policy Optimization (PPO)

### Implementation Summary (`ppo.py`)
- **Decoupled Actor-Critic**: Independent 256-256 MLPs with orthogonal initialization (`_layer_init`), optional `RunningObsNorm` buffers (frozen during `eval()`), and optional gSDE (`--use_sde`) for smooth state-dependent exploration.
- **`compute_gae`**: Computes Generalized Advantage Estimation `delta_t = r_t + gamma * V(s_{t+1}) * (1 - d_t) - V(s_t)` and `A_t = delta_t + gamma * lambda * (1 - d_t) * A_{t+1}`, with time-limit truncation bootstrapped via `r_t + gamma * V(s_{t+1})`.
- **`update_policy`**: Standardizes rollout advantages, performs `update_epochs = 10` shuffled mini-batch epochs optimizing the clipped surrogate objective `min(r_t * A_t, clip(r_t, 1 - eps, 1 + eps) * A_t)` minus `entropy_coef * H(pi)` and `0.5 * (V(s) - R)^2`, with gradient norm clipping (`grad_clip = 0.5`). Logs `actor_loss`, `critic_loss`, `entropy_loss`, `approx_kl`, `clipfrac`, `explained_variance`, and `policy_std`.

### Performance & Analysis
- **`MountainCarContinuous-v0` (Solved)**: Using `lr=3e-4, gamma=0.999, gae_lambda=0.9, batch_size=64, norm_obs=True, use_sde=True`, PPO + gSDE crossed `+90.0` before 40k steps (`+92.66` eval at 40,382 steps) and converged smoothly to `+95.07 ± 0.28` training return and **`+95.17 ± 0.17`** over 20 deterministic eval episodes (`>= +90.0` **PASS**). Critic MSE loss decayed cleanly from `~2,100` to `< 0.1` as value predictions locked onto the true discounted return.
- **`BipedalWalker-v3` (Part 1B Baseline)**: With starter defaults (`lr=5e-5, batch_size=256, rollout_steps=2048, gamma=0.99, ent=0.01`) over 200,424 steps, PPO reached `+39.97 ± 17.30` (max `+76.27`) in training and `-109.56 ± 0.13` in deterministic eval. At `lr=5e-5`, gradient steps are simply too conservative to stabilize forward walking within 200k steps, setting up the systematic tuning in Part 2.
- **Plots**: `plots/part1_mountaincar_reward.png`, `plots/part1_bipedal_reward.png`, `plots/part1_ppo_losses.png`.

---

## Part 1C (BONUS): Soft Actor-Critic (SAC)

### Implementation Summary (`sac.py`)
- **`PolicyNetwork.sample`**: Outputs Gaussian `mean` and clamped `log_std` (`[-20, 2]`), applies the reparameterization trick `u = Normal(mean, std).rsample()`, squashes `a = tanh(u)`, and computes the exact Jacobian log-probability correction `log pi(a|s) = log N(u|mu, sigma) - sum log(1 - tanh^2(u) + eps)`.
- **`SACAgent.update_parameters`**: Uses twin Q-networks `Q1, Q2` with Polyak-averaged targets (`tau`), detached entropy temperature `alpha` tuned automatically toward target entropy `-dim(A)`, and joint `Q1+Q2` critic (`critic_optimizer`), `policy_optimizer`, and `alpha_optimizer` Adam updates once `total_steps >= start_steps`.

### Performance & Analysis
- **`MountainCarContinuous-v0` (Solved)**: With `lr=3e-4, tau=0.01, alpha_init=0.5, start_steps=5000, ou_warmup=True`, OU exploration discovers the goal within the first 10k steps; Q-values and policy converge almost immediately, hitting `+94.94` eval at 40k steps and finishing at `+94.94 ± 0.27` training / **`+94.98 ± 0.33`** over 20 deterministic eval episodes (`>= +90.0` **PASS**). Temperature `alpha` decays smoothly from `0.5` down to `~0.07`.
- **`BipedalWalker-v3` (Solved)**: With `lr=7e-4, tau=0.01, alpha_init=0.2, start_steps=10000, buffer_size=300000` over 500,509 steps, SAC crossed the `+300` threshold by step `152,071` (`+303.26` eval), reached `+320.65` at 302k, and achieved a final TB evaluation of **`+328.86`** (`+328.79 ± 0.70` across 20/20 held-out seeds, and `326.64 ± 21.98` with 99/100 ≥ 300 across 100 seeds — **PASS**). Policy loss decreases smoothly to `~-33` as Q-values increase while critic MSBE remains well-behaved (`~0.5–5`).
- **Plots**: `plots/bonus_sac_mountaincar_diagnostics.png`, `plots/bonus_sac_bipedal_diagnostics.png`.

---

## Collective Analysis for Part 1 (REINFORCE vs. PPO vs. SAC)

1. **Sample Efficiency**: **SAC >> PPO >> REINFORCE**. Off-policy replay reuse (`256`-sample gradient steps per env step) enables SAC to cross `+300` on `BipedalWalker-v3` in just `152k` environment steps (and solve `MountainCarContinuous-v0` in `< 20k` steps after OU warmup), whereas on-policy PPO requires ~800k–2.5M steps (after tuning) on `BipedalWalker-v3`, and REINFORCE fails to solve either task within 200k steps.
2. **Variance & Credit Assignment**: REINFORCE suffers from high Monte-Carlo trajectory variance and cannot distinguish good and bad mid-episode actions. PPO cuts variance via a learned critic + GAE (`lambda=0.95`) and bounds policy drift via clipping, while SAC eliminates rollout-horizon variance entirely via twin clipped off-policy Q-learning (`min(Q1, Q2)`).
3. **Exploration Mechanisms**: Maximum-entropy RL (`alpha * H(pi)`) in SAC plus OU warmup naturally drives broad state coverage; standard Gaussian PPO benefits from either gSDE (`MountainCarContinuous-v0`) or larger multi-trajectory rollouts (`BipedalWalker-v3`).

---

## Part 2A: PPO Hyperparameter Sweep on `BipedalWalker-v3`

All Part 2A experiments isolate one hyperparameter at a time for 200k environment steps (`seed=42`, `rollout_steps=2048`) relative to the Part 1B baseline (`lr=5e-5, clip=0.2, ent=0.01, bs=256`):

| Ablation Group | Fixed Params | Swept Value | Steps | Train Last-10 (Mean ± Std) | Max Train | Final Eval | Max Eval |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Clip Ratio** | `lr=5e-5, ent=0.01, bs=256` | `clip = 0.1` | 200,366 | `-57.77 ± 29.16` | `-35.12` | `-27.13` | `-27.13` |
| **Clip Ratio** | `lr=5e-5, ent=0.01, bs=256` | `clip = 0.2` | 200,424 | **`+39.97 ± 17.30`** | **`+76.27`** | `-109.55` | **`-6.90`** |
| **Clip Ratio** | `lr=5e-5, ent=0.01, bs=256` | `clip = 0.3` | 201,223 | `+18.77 ± 45.83` | `+48.89` | `-115.42` | `+71.14` |
| **Entropy Coef** | `lr=5e-5, clip=0.2, bs=256` | `ent = 0.0` | 200,891 | `-72.43 ± 39.75` | `-26.60` | `-34.05` | `-20.66` |
| **Entropy Coef** | `lr=5e-5, clip=0.2, bs=256` | `ent = 0.01` | 200,424 | **`+39.97 ± 17.30`** | **`+76.27`** | `-109.55` | `-6.90` |
| **Entropy Coef** | `lr=5e-5, clip=0.2, bs=256` | `ent = 0.05` | 201,148 | `-35.11 ± 60.20` | `+21.41` | **`+4.74`** | **`+4.74`** |
| **Learning Rate** | `clip=0.2, ent=0.01, bs=256` | `lr = 1e-5` | 201,122 | `-91.51 ± 20.59` | `-51.83` | `-102.60` | `-91.96` |
| **Learning Rate** | `clip=0.2, ent=0.01, bs=256` | `lr = 5e-5` | 200,424 | `+39.97 ± 17.30` | `+76.27` | `-109.55` | `-6.90` |
| **Learning Rate** | `clip=0.2, ent=0.01, bs=256` | `lr = 3e-4` | 200,466 | `+44.79 ± 113.55` | `+169.90` | `+42.72` | `+161.31` |
| **Learning Rate** | `clip=0.2, ent=0.01, bs=256` | **`lr = 1e-3`** | 200,120 | **`+197.84 ± 61.07`** | **`+235.33`** | **`+279.44`** | **`+279.44`** |
| **Mini-Batch Size** | `lr=3e-4, clip=0.2, ent=0.01` | `bs = 64` | 200,642 | `+42.97 ± 98.19` | `+120.67` | `+39.62` | `+128.11` |
| **Mini-Batch Size** | `lr=3e-4, clip=0.2, ent=0.01` | `bs = 128` | 201,155 | **`+45.29 ± 142.98`** | **`+205.80`** | **`+81.44`** | `+148.29` |
| **Mini-Batch Size** | `lr=3e-4, clip=0.2, ent=0.01` | `bs = 256` | 200,466 | `+44.79 ± 113.55` | `+169.90` | `+42.72` | **`+161.31`** |

### Key Insights from Part 2A
1. **Learning rate is the dominant bottleneck**: Stepping from `5e-5` to `1e-3` turned a failing `-109.55` policy into `+279.44` eval within 200k steps (`lr=1e-5` stayed trapped at `-91.51`).
2. **Clip ratio `0.2` balances trust region and progress**: `clip=0.1` over-constrains updates (`-57.77`), while `clip=0.3` shows sharper variance drops (`±45.83`).
3. **Mini-batch size vs. stability**: At `lr=3e-4`, `bs=128` reached higher peak train reward (`+205.80`), while `bs=256` gave steadier evaluation (`+161.31` max eval) with cleaner gradient averaging—critical once paired with higher learning rates (`1e-3`).
4. **Entropy bonus helps early exploration (`0.01`)**, but once a walking gait emerges over long budgets, persistent positive entropy adds torque jitter (`ent=0.0` + `anneal_lr` sharpens deterministic eval in Part 2B).

**Plots:** `plots/part2a_clip_ratio_ablation.png`, `plots/part2a_entropy_coef_ablation.png`, `plots/part2a_lr_ablation.png`, `plots/part2a_batch_size_ablation.png`.

---

## Part 2B: Best Tuned PPO Configuration vs. Part 1 Baseline

### Selected Configuration & Rationale
Building directly on Part 2A (`lr=1e-3`, `clip=0.2`, `bs=256`), three principled adjustments closed the remaining gap past `+300.0`:
- **`rollout_steps = 8192`** (instead of `2048`): Because a full `BipedalWalker-v3` episode spans ~1,000–1,600 steps, `2048`-step rollouts contain only ~1.3 trajectories—allowing a single rough-terrain stumble to skew an entire PPO update or trap the agent in a slow, ultra-cautious 1,590-step gait (`~298` plateau). Collecting `8192` steps (~6–7 episodes) per update stabilizes policy gradients across diverse terrain seeds.
- **`gamma = 0.995`, `gae_lambda = 0.95`**: Extends the effective planning horizon from `100` to `200` steps so the critic rewards brisk finish-line completion rather than idling.
- **`entropy_coef = 0.0` with linear `anneal_lr` over `2.5M` steps (`grad_clip = 0.5`)**: Allows aggressive early exploration at `lr=1e-3` and then anneals policy updates smoothly to lock in a low-variance, energy-efficient stride.

### Results (`BipedalWalker-v3`)
- **Part 1B Baseline (`200k` steps)**: Last-10 train `+39.97 ± 17.30`, deterministic eval **`-109.56 ± 0.13`**.
- **Matched-Horizon (`200k` steps) vs. Full-Budget (`2.5M` steps) Tradeoff**: At `200,745` steps, `rollout_steps=8192` reaches only `+0.62` TB eval (because `8192`-step rollouts take 4x fewer policy updates per `200k` steps than `rollout_steps=2048`, which reached `+279.44` at `lr=1e-3`). However, the 4x larger multi-trajectory batch eliminates the ~298 slow-gait plateau once given full convergence budget.
- **Part 2B Tuned PPO (`2,500,034` steps)**:
  - Crossed `+300` by step `802,524` (`+305.08` eval), experienced a single transient gait-destabilization dip around `1.56M–1.60M` steps (`-112.47` eval at `1,604,651` while `lr` was still ~`3.6e-4`), and recovered immediately via `clip=0.2` and continued linear `lr` annealing back to `+304.79` (`1.81M`), peaking at **`+308.01`** eval (`2.41M`), and finishing with Last-10 training return **`+306.50 ± 1.79`** (max `+311.92`) and TB final eval **`+306.66`**.
  - **20-Episode Deterministic Eval (seeds 0–19)**: **`+307.75 ± 1.48`** (`min = 305.62, max = 310.34`, **20/20 ≥ 300.0** — **PASS**).
  - **100-Episode Deterministic Eval (seeds 0–99)**: **`+301.54 ± 44.63`** (**98/100 ≥ 300.0**, mean episode length `1,204` — **PASS**).
- **Plot**: `plots/part2b_best_vs_baseline.png`.

### Scope & Limitations
- **Single Training Seed**: Each kept configuration was trained with a single random seed (`seed=42`), while generalization was evaluated across 20 and 100 distinct held-out environment seeds (`0–99`). Because on-policy RL on `BipedalWalker-v3` exhibits seed sensitivity across training trajectories, multi-seed training replication (`3–5` seeds) remains future work.
